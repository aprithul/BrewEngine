A custom game engine in making:
- SDL2 for windowing, events
- Opengl 4.1 renderer
- Dear ImGUI for GUI
- g++, C++11

Now compiles on both Windows 10 and Mac OS catalina. Install glew before building.




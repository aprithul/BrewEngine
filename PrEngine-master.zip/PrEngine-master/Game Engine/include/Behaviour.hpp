#ifndef BEHAVIOUR_COMPONENT_HPP
#define BEHAVIOUR_COMPONENT_HPP

#include "Module.hpp"

namespace PrEngine
{
    class Behaviour
    {
        public:
            Behaviour();
            virtual ~Behaviour();
    };
}

#endif

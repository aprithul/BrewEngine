#include "RenderLayer.hpp"

namespace PrEngine
{
    RenderLayer::~RenderLayer()
    {
        
    }
}
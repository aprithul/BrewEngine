#include "AudioManager.hpp"

namespace PrEngine
{
    AudioManager::AudioManager(const std::string& name, int priority):Module(name, priority)
    {

    }

    AudioManager::~AudioManager()
    {

    }

    void AudioManager::start()
    {

    }

    void AudioManager::update()
    {

    }

    void AudioManager::end()
    {

    }
}
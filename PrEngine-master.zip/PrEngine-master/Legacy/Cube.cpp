#include "Cube.hpp"

namespace PrEngine{

    Cube::Cube(Graphics* graphics):Entity3D(graphics)
    {

    }

    Cube::~Cube()
    {

    }

    void Cube::start()
    {
    }

    void Cube::update()
    {
        
    }

    void Cube::end()
    {

    }


}